#ifndef __GLOBAL_H_
#define __GLOBAL_H_

#include <iostream>
#include <fstream>
#include <string>
#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <time.h>
#include <memory.h>
#include <vector>
#include <cassert>
#include <algorithm>

using namespace std;
#include "random.h"

#define PI  3.1415926535897932384626433832795
//------------- Parameters in test instance ------------------
int     nvar,  nobj;                    //  the number of variables and objectives
vector<double>  lowBound,   uppBound;   //  lower and upper bounds of variables
char    strTestInstance[256];
char    strFunctionType[256];
int     num_max_evulation;
char	strCrossType[256];
//------------- Parameters in random number ------------------
int     seed    = 177;
long    rnd_uni_init;        
//------------- Parameters in MOEA/D -------------------------
vector <double> idealpoint;
vector <double> nad_point;
int		etax    = 20, 	etam    = 20;   // distribution indexes of crossover and mutation
double  realx,  realm,  realb = 1;    // crossover, mutation, selection probabilities

int inst;
int position_parameters = 2;

//----Parameters in inintialization-------//
int Multiple = 10;
vector<int> DiversityIndexs, ConvergenceIndexs;
//----Parameters in grouping-------//
vector<vector<vector<int> > > Dependent;
vector<vector<int> > Effect;
vector<int> Control;

int NumIndependentAnalysis = 6;
int NumDependentAnalysis = 5;
int NumControlAnalysis = 20;
//vector<vector<vector<int> > > Group;
vector<vector<int> > Groups;
//-------------Nondominated sorting to analyze the property of variable control converge and diversity-------------//
vector<vector<double> > S;
vector< vector<int> > front;
vector< vector< int > > donimate;
vector<int>	num_donimated;
//------------------------------------------------------------//
char    strUpdateSolutionMode[256];

void ParameterSet(void)
{
	int i =0;
	if(!strcmp("UF1", strTestInstance))
	{
		lowBound = vector<double>(nvar, 0);
		uppBound = vector<double>(nvar, 1);
		for (i=1;i<nvar;i++)
		{
			lowBound[i] = -1;
			uppBound[i] = 1;
		}
		strcpy(strFunctionType,"_MTCH1"); 
		num_max_evulation = 10000000;
		strcpy(strCrossType,"DE");
		return;
	}
	if(!strcmp("UF2", strTestInstance))
	{
		lowBound = vector<double>(nvar, 0);
		uppBound = vector<double>(nvar, 1);
		for (i=1;i<nvar;i++)
		{
			lowBound[i] = -1;
			uppBound[i] = 1;
		}
		strcpy(strFunctionType,"_MTCH1"); 
		num_max_evulation = 10000000;
		strcpy(strCrossType,"DE");
		return;
	}
	if(!strcmp("UF3", strTestInstance))
	{
		lowBound = vector<double>(nvar, 0);
		uppBound = vector<double>(nvar, 1);	
		strcpy(strFunctionType,"_MTCH1"); 
		num_max_evulation = 300000;
		strcpy(strCrossType,"DE");
		return;
	}
	if(!strcmp("UF4", strTestInstance))
	{
		lowBound = vector<double>(nvar, 0);
		uppBound = vector<double>(nvar, 1);
		for (i=1;i<nvar;i++)
		{
			lowBound[i] = -2;
			uppBound[i] = 2;
		}
		strcpy(strFunctionType,"_MTCH1"); 
		num_max_evulation = 300000;
		strcpy(strCrossType,"DE");
		return;
	}
	if(!strcmp("UF5", strTestInstance))
	{
		lowBound = vector<double>(nvar, 0);
		uppBound = vector<double>(nvar, 1);
		for (i=1;i<nvar;i++)
		{
			lowBound[i] = -1;
			uppBound[i] = 1;
		}
		strcpy(strFunctionType,"_MTCH1"); 
		num_max_evulation = 300000;
		strcpy(strCrossType,"DE");
		return;
	}
	if(!strcmp("UF6", strTestInstance))
	{
		lowBound = vector<double>(nvar, 0);
		uppBound = vector<double>(nvar, 1);
		for (i=1;i<nvar;i++)
		{
			lowBound[i] = -1;
			uppBound[i] = 1;
		}
		strcpy(strFunctionType,"_MTCH1"); 
		num_max_evulation = 300000;
		strcpy(strCrossType,"DE");
		return;
	}
	if(!strcmp("UF7", strTestInstance))
	{
		lowBound = vector<double>(nvar, 0);
		uppBound = vector<double>(nvar, 1);
		for (i=1;i<nvar;i++)
		{
			lowBound[i] = -1;
			uppBound[i] = 1;
		}
		strcpy(strFunctionType,"_MTCH1"); 
		num_max_evulation = 300000;
		strcpy(strCrossType,"DE");
		return;
	}
	if(!strcmp("UF8", strTestInstance))
	{
		lowBound = vector<double>(nvar, 0);
		uppBound = vector<double>(nvar, 1);
		for (i=2;i<nvar;i++)
		{
			lowBound[i] = -2;
			uppBound[i] = 2;
		}
		strcpy(strFunctionType,"_MTCH1"); 
		num_max_evulation = 300000;
		strcpy(strCrossType,"DE");
		return;
	}
	if(!strcmp("UF9", strTestInstance))
	{
		lowBound = vector<double>(nvar, 0);
		uppBound = vector<double>(nvar, 1);
		for (i=2;i<nvar;i++)
		{
			lowBound[i] = -2;
			uppBound[i] = 2;
		}
		strcpy(strFunctionType,"_MTCH1"); 
		num_max_evulation = 300000;
		strcpy(strCrossType,"DE");
		return;
	}
	if(!strcmp("UF10", strTestInstance))
	{
		lowBound = vector<double>(nvar, 0);
		uppBound = vector<double>(nvar, 1);
		for (i=2;i<nvar;i++)
		{
			lowBound[i] = -2;
			uppBound[i] = 2;
		}
		strcpy(strFunctionType,"_MTCH1"); 
		num_max_evulation = 300000;
		strcpy(strCrossType,"DE");
		return;
	}
	if (!strcmp("R2_DTLZ2_M5", strTestInstance))
	{
		double low30[] = {-1.773,	-1.846,	-1.053,	-2.370,	-1.603,	-1.878,	-1.677,	-0.935,	-1.891,	-0.964,	-0.885,	-1.690,	-2.235,	-1.541,	-0.720,	0.000,	0.000,	0.000,	0.000,	0.000,	0.000,	0.000,	0.000,	0.000,	0.000,	0.000,	0.000,	0.000,	0.000,	0.000};
		double upp30[] = {1.403,	1.562,	2.009,	0.976,	1.490,	1.334,	1.074,	2.354,	1.462,	2.372,	2.267,	1.309,	0.842,	1.665,	2.476,	1.000,	1.000,	1.000,	1.000,	1.000,	1.000,	1.000,	1.000,	1.000,	1.000,	1.000,	1.000,	1.000,	1.000,	1.000};
		lowBound = vector<double>(nvar, 0);
		uppBound = vector<double>(nvar, 1);
		for (i=0;i<nvar;i++)
		{
			lowBound[i] = low30[i];
			uppBound[i] = upp30[i];
		}
		return;
	}
	if (!strcmp("R2_DTLZ3_M5", strTestInstance))
	{
		double low30[] = {-1.773,	-1.846,	-1.053,	-2.370,	-1.603,	-1.878,	-1.677,	-0.935,	-1.891,	-0.964,	-0.885,	-1.690,	-2.235,	-1.541,	-0.720,	0.000,	0.000,	0.000,	0.000,	0.000,	0.000,	0.000,	0.000,	0.000,	0.000,	0.000,	0.000,	0.000,	0.000,	0.000};
		double upp30[] = {1.403,	1.562,	2.009,	0.976,	1.490,	1.334,	1.074,	2.354,	1.462,	2.372,	2.267,	1.309,	0.842,	1.665,	2.476,	1.000,	1.000,	1.000,	1.000,	1.000,	1.000,	1.000,	1.000,	1.000,	1.000,	1.000,	1.000,	1.000,	1.000,	1.000};
		lowBound = vector<double>(nvar, 0);
		uppBound = vector<double>(nvar, 1);
		for (i=0;i<nvar;i++)
		{
			lowBound[i] = low30[i];
			uppBound[i] = upp30[i];
		}
		return;
	}
	//if (!strcmp("WFG1_M5", strTestInstance))
	//{
	//	lowBound = vector<double>(nvar, 0);
	//	uppBound = vector<double>(nvar, 1);
	//	return;
	//}	
	if (!strcmp("ZDT1", strTestInstance))
	{
		lowBound = vector<double>(nvar, 0);
		uppBound = vector<double>(nvar, 1);
		strcpy(strFunctionType,"_MTCH1"); 
		num_max_evulation = 50000;
		strcpy(strCrossType,"SBX");
		return;
	}
	if (!strcmp("ZDT2", strTestInstance))
	{
		lowBound = vector<double>(nvar, 0);
		uppBound = vector<double>(nvar, 1);		
		strcpy(strFunctionType,"_MTCH1"); 
		num_max_evulation = 50000;
		strcpy(strCrossType,"SBX");
		return;
	}
	if (!strcmp("ZDT3", strTestInstance))
	{
		lowBound = vector<double>(nvar, 0);
		uppBound = vector<double>(nvar, 1);
		strcpy(strFunctionType,"_MTCH2"); 
		num_max_evulation = 50000;
		strcpy(strCrossType,"SBX");
		return;
	}
	if (!strcmp("ZDT4", strTestInstance))
	{
		lowBound = vector<double>(nvar, 0);
		uppBound = vector<double>(nvar, 1);
		for (i=2; i<=nvar; i++)
		{
			lowBound[i-1] = -5;
			uppBound[i-1] = 5;
		}
		strcpy(strFunctionType,"_MTCH1"); 
		num_max_evulation = 10000000;
		strcpy(strCrossType,"SBX");
		return;
	}
	if (!strcmp("ZDT6", strTestInstance))
	{
		lowBound = vector<double>(nvar, 0);
		uppBound = vector<double>(nvar, 1);
		strcpy(strFunctionType,"_MTCH1"); 
		num_max_evulation = 50000;
		strcpy(strCrossType,"SBX");
		return;
	}
	if (!strcmp("DTLZ1", strTestInstance))
	{
		lowBound = vector<double>(nvar, 0);
		uppBound = vector<double>(nvar, 1);
		strcpy(strFunctionType,"_MTCH1"); 
		if (nobj == 3) num_max_evulation = 10000000;
		else if (nobj == 4) num_max_evulation = 500000;
		else if (nobj == 6) num_max_evulation = 1000000;
		strcpy(strCrossType,"SBX");
		return;
	}
	if (!strcmp("DTLZ2", strTestInstance))
	{
		lowBound = vector<double>(nvar, 0);
		uppBound = vector<double>(nvar, 1);
		strcpy(strFunctionType,"_MTCH1"); 
		if (nobj == 3) num_max_evulation = 10000000;
		else if (nobj == 4) num_max_evulation = 500000;
		else if (nobj == 6) num_max_evulation = 1000000;
		strcpy(strCrossType,"SBX");
		return;
	}
	if (!strcmp("DTLZ3", strTestInstance))
	{
		lowBound = vector<double>(nvar, 0);
		uppBound = vector<double>(nvar, 1);
		strcpy(strFunctionType,"_MTCH1"); 
		if (nobj == 3) num_max_evulation = 75000*7;
		else if (nobj == 4) num_max_evulation = 500000;
		else if (nobj == 6) num_max_evulation = 1000000;
		strcpy(strCrossType,"SBX");
		return;
	}
	if (!strcmp("DTLZ4", strTestInstance))
	{
		lowBound = vector<double>(nvar, 0);
		uppBound = vector<double>(nvar, 1);
		strcpy(strFunctionType,"_MTCH1"); 
		if (nobj == 3) num_max_evulation = 75000;
		else if (nobj == 4) num_max_evulation = 500000;
		else if (nobj == 6) num_max_evulation = 1000000;
		strcpy(strCrossType,"SBX");
		return;
	}
	if (!strcmp("DTLZ7", strTestInstance))
	{
		lowBound = vector<double>(nvar, 0);
		uppBound = vector<double>(nvar, 1);
		strcpy(strFunctionType,"_MTCH2"); 
		num_max_evulation = 75000;
		strcpy(strCrossType,"SBX");
		return;
	}
	if(!strcmp("WFG1", strTestInstance))
	{
		lowBound = vector<double>(nvar, 0);
		uppBound = vector<double>(nvar, 2);
		for (i = 1; i < nvar; i++)		uppBound[i] = 2*(i + 1);
		strcpy(strFunctionType,"_MTCH2"); 
		num_max_evulation = 300000;
		strcpy(strCrossType,"SBX");
		return;
	}
	if(!strcmp("WFG2", strTestInstance))
	{
		lowBound = vector<double>(nvar, 0);
		uppBound = vector<double>(nvar, 2);
		for (i = 1; i < nvar; i++)		uppBound[i] = 2*(i + 1);
		strcpy(strFunctionType,"_MTCH2"); 
		num_max_evulation = 300000;
		strcpy(strCrossType,"SBX");
		return;
	}
	if(!strcmp("WFG3", strTestInstance))
	{
		lowBound = vector<double>(nvar, 0);
		uppBound = vector<double>(nvar, 2);
		for (i = 1; i < nvar; i++)		uppBound[i] = 2*(i + 1);
		strcpy(strFunctionType,"_MTCH2"); 
		num_max_evulation = 300000;
		strcpy(strCrossType,"SBX");
		return;
	}
	if(!strcmp("WFG4", strTestInstance))
	{
		lowBound = vector<double>(nvar, 0);
		uppBound = vector<double>(nvar, 2);
		for (i = 1; i < nvar; i++)		uppBound[i] = 2*(i + 1);
		strcpy(strFunctionType,"_MTCH2"); 
		if (nobj == 3) num_max_evulation = 300000;
		else if (nobj == 4) num_max_evulation = 500000;
		else if (nobj == 6) num_max_evulation = 1000000;
		strcpy(strCrossType,"SBX");
		return;
	}
	if(!strcmp("WFG5", strTestInstance))
	{
		lowBound = vector<double>(nvar, 0);
		uppBound = vector<double>(nvar, 2);
		for (i = 1; i < nvar; i++)		uppBound[i] = 2*(i + 1);
		strcpy(strFunctionType,"_MTCH2"); 
		if (nobj == 3) num_max_evulation = 300000;
		else if (nobj == 4) num_max_evulation = 500000;
		else if (nobj == 6) num_max_evulation = 1000000;
		strcpy(strCrossType,"SBX");
		return;
	}
	if(!strcmp("WFG6", strTestInstance))
	{
		lowBound = vector<double>(nvar, 0);
		uppBound = vector<double>(nvar, 2);
		for (i = 1; i < nvar; i++)		uppBound[i] = 2*(i + 1);
		strcpy(strFunctionType,"_MTCH2"); 
		if (nobj == 3) num_max_evulation = 300000;
		else if (nobj == 4) num_max_evulation = 500000;
		else if (nobj == 6) num_max_evulation = 1000000;
		strcpy(strCrossType,"SBX");
		return;
	}
	if(!strcmp("WFG7", strTestInstance))
	{
		lowBound = vector<double>(nvar, 0);
		uppBound = vector<double>(nvar, 2);
		for (i = 1; i < nvar; i++)		uppBound[i] = 2*(i + 1);
		strcpy(strFunctionType,"_MTCH2"); 
		if (nobj == 3) num_max_evulation = 300000;
		else if (nobj == 4) num_max_evulation = 500000;
		else if (nobj == 6) num_max_evulation = 1000000;
		strcpy(strCrossType,"SBX");
		return;
	}
	if(!strcmp("WFG8", strTestInstance))
	{
		lowBound = vector<double>(nvar, 0);
		uppBound = vector<double>(nvar, 2);
		for (i = 1; i < nvar; i++)		uppBound[i] = 2*(i + 1);
		strcpy(strFunctionType,"_MTCH2"); 
		if (nobj == 3) num_max_evulation = 300000;
		else if (nobj == 4) num_max_evulation = 500000;
		else if (nobj == 6) num_max_evulation = 1000000;
		strcpy(strCrossType,"SBX");
		return;
	}
	if(!strcmp("WFG9", strTestInstance))
	{
		lowBound = vector<double>(nvar, 0);
		uppBound = vector<double>(nvar, 2);
		for (i = 1; i < nvar; i++)		uppBound[i] = 2*(i + 1);
		strcpy(strFunctionType,"_MTCH2"); 
		if (nobj == 3) num_max_evulation = 300000;
		else if (nobj == 4) num_max_evulation = 500000;
		else if (nobj == 6) num_max_evulation = 1000000;
		strcpy(strCrossType,"SBX");
		return;
	}
	if (!strcmp("MOP1", strTestInstance))
	{
		lowBound = vector<double>(nvar, 0);
		uppBound = vector<double>(nvar, 1);
		strcpy(strFunctionType,"_MTCH1"); 
		num_max_evulation = 300000;
		strcpy(strCrossType,"DE");
		return;
	}
	if (!strcmp("MOP2", strTestInstance))
	{
		lowBound = vector<double>(nvar, 0);
		uppBound = vector<double>(nvar, 1);
		strcpy(strFunctionType,"_MTCH1"); 
		num_max_evulation = 300000;
		strcpy(strCrossType,"DE");
		return;
	}
	if (!strcmp("MOP3", strTestInstance))
	{
		lowBound = vector<double>(nvar, 0);
		uppBound = vector<double>(nvar, 1);
		strcpy(strFunctionType,"_MTCH1"); 
		num_max_evulation = 300000;
		strcpy(strCrossType,"DE");
		return;
	}
	if (!strcmp("MOP4", strTestInstance))
	{
		lowBound = vector<double>(nvar, 0);
		uppBound = vector<double>(nvar, 1);
		strcpy(strFunctionType,"_MTCH1"); 
		num_max_evulation = 300000;
		strcpy(strCrossType,"DE");
		return;
	}
	if (!strcmp("MOP5", strTestInstance))
	{
		lowBound = vector<double>(nvar, 0);
		uppBound = vector<double>(nvar, 1);
		strcpy(strFunctionType,"_MTCH1"); 
		num_max_evulation = 300000;
		strcpy(strCrossType,"DE");
		return;
	}
	if (!strcmp("MOP6", strTestInstance))
	{
		lowBound = vector<double>(nvar, 0);
		uppBound = vector<double>(nvar, 1);
		strcpy(strFunctionType,"_MTCH1"); 
		num_max_evulation = 300000;
		strcpy(strCrossType,"DE");
		return;
	}
	if (!strcmp("MOP7", strTestInstance))
	{
		lowBound = vector<double>(nvar, 0);
		uppBound = vector<double>(nvar, 1);
		strcpy(strFunctionType,"_MTCH1"); 
		num_max_evulation = 300000;
		strcpy(strCrossType,"DE");
		return;
	}
	if(!strcmp("PStar", strTestInstance))
	{
		lowBound = vector<double>(nvar, 0.0);
		uppBound = vector<double>(nvar, 100.0);
		strcpy(strFunctionType,"_MTCH2"); 
		num_max_evulation = 30000;
		strcpy(strCrossType,"SBX");
		return;
	}
	if(!strcmp("LPMS", strTestInstance))
	{
		lowBound = vector<double>(nvar, -4.9);
		uppBound = vector<double>(nvar, 3.2);
		lowBound[1] = -3.5;
		uppBound[1] = 6;
		strcpy(strFunctionType,"_MTCH2"); 
		num_max_evulation = 75000;
		strcpy(strCrossType,"SBX");
		return;
	}
	if(!strcmp("DTLZ5_3", strTestInstance))
	{
		lowBound = vector<double>(nvar, 0.0);
		uppBound = vector<double>(nvar, 1.0);
		strcpy(strFunctionType,"_MTCH2"); 
		num_max_evulation = 300000;
		strcpy(strCrossType,"SBX");
		return;
	}
	if (!strcmp("DTLZ2_Convex", strTestInstance))
	{
		lowBound = vector<double>(nvar, 0);
		uppBound = vector<double>(nvar, 1);
		strcpy(strFunctionType,"_MTCH1"); 
		num_max_evulation = 75000;
		strcpy(strCrossType,"SBX");
		return;
	}
}

#endif