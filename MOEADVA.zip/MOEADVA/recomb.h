#ifndef _RECOMBINATION_H_
#define _RECOMBINATION_H_

#include "global.h"
#include "individual.h"

void realmutation(CIndividual &ind, double rate)
{
    double rnd, delta1, delta2, mut_pow, deltaq;
    double y, yl, yu, val, xy;
	double eta_m = etam;

	int    id_rnd = int(rnd_uni(&rnd_uni_init)*nvar);

    for (int j=0; j<nvar; j++)    {
        if (rnd_uni(&rnd_uni_init)<=rate)        {
            y  = ind.x_var[j];
            yl = lowBound[j];
            yu = uppBound[j];
            delta1 = (y-yl)/(yu-yl);
            delta2 = (yu-y)/(yu-yl);
            rnd = rnd_uni(&rnd_uni_init);
            mut_pow = 1.0/(eta_m+1.0);
            if (rnd <= 0.5)            {
                xy = 1.0-delta1;
                val = 2.0*rnd+(1.0-2.0*rnd)*(pow(xy,(eta_m+1.0)));
                deltaq =  pow(val,mut_pow) - 1.0;
            }
            else            {
                xy = 1.0-delta2;
                val = 2.0*(1.0-rnd)+2.0*(rnd-0.5)*(pow(xy,(eta_m+1.0)));
                deltaq = 1.0 - (pow(val,mut_pow));
            }
            y = y + deltaq*(yu-yl);
            if (y<yl)                y = yl;
            if (y>yu)                y = yu;
            ind.x_var[j] = y;
        }
    }
    return;
}

/* Routine for real polynomial mutation of an T */
void realmutation(CIndividual &ind, double rate, vector<int> &indices)
{
    double rnd, delta1, delta2, mut_pow, deltaq;
    double y, yl, yu, val, xy;
	double eta_m = etam;

	int    id_rnd = int(rnd_uni(&rnd_uni_init)*nvar);

    for (int j=0; j<indices.size(); j++)
    {
        if (rnd_uni(&rnd_uni_init)<=rate)
        {
            y  = ind.x_var[indices[j]];
            yl = lowBound[indices[j]];
            yu = uppBound[indices[j]];
            delta1 = (y-yl)/(yu-yl);
            delta2 = (yu-y)/(yu-yl);
            rnd = rnd_uni(&rnd_uni_init);
            mut_pow = 1.0/(eta_m+1.0);
            if (rnd <= 0.5)
            {
                xy = 1.0-delta1;
                val = 2.0*rnd+(1.0-2.0*rnd)*(pow(xy,(eta_m+1.0)));
                deltaq =  pow(val,mut_pow) - 1.0;
            }
            else
            {
                xy = 1.0-delta2;
                val = 2.0*(1.0-rnd)+2.0*(rnd-0.5)*(pow(xy,(eta_m+1.0)));
                deltaq = 1.0 - (pow(val,mut_pow));
            }
            y = y + deltaq*(yu-yl);
            if (y<yl)
                y = yl;
            if (y>yu)
                y = yu;
            ind.x_var[indices[j]] = y;
        }
    }
    return;
}


/* Routine for real variable SBX crossover */
template <class T>
void real_sbx_xoverA(CIndividual &parent1, CIndividual &parent2, CIndividual &child1, CIndividual &child2)
{
    double rand;
    double y1, y2, yl, yu;
    double c11, c22;
    double alpha, beta, betaq;
	double eta_c = etax;
    if (rnd_uni(&rnd_uni_init) <= 1.0) 
    {
        for (int i=0; i<nvar; i++)
        {
            if (rnd_uni(&rnd_uni_init)<=0.5 )
            {
                if (fabs(parent1.x_var[i]-parent2.x_var[i]) > EPS)
                {
                    if (parent1.x_var[i] < parent2.x_var[i])
                    {
                        y1 = parent1.x_var[i];
                        y2 = parent2.x_var[i];
                    }
                    else
                    {
                        y1 = parent2.x_var[i];
                        y2 = parent1.x_var[i];
                    }
                    yl = lowBound[i];
                    yu = uppBound[i];
                    rand = rnd_uni(&rnd_uni_init);
                    beta = 1.0 + (2.0*(y1-yl)/(y2-y1));
                    alpha = 2.0 - pow(beta,-(eta_c+1.0));
                    if (rand <= (1.0/alpha))
                    {
                        betaq = pow ((rand*alpha),(1.0/(eta_c+1.0)));
                    }
                    else
                    {
                        betaq = pow ((1.0/(2.0 - rand*alpha)),(1.0/(eta_c+1.0)));
                    }
                    c11 = 0.5*((y1+y2)-betaq*(y2-y1));
                    beta = 1.0 + (2.0*(yu-y2)/(y2-y1));
                    alpha = 2.0 - pow(beta,-(eta_c+1.0));
                    if (rand <= (1.0/alpha))
                    {
                        betaq = pow ((rand*alpha),(1.0/(eta_c+1.0)));
                    }
                    else
                    {
                        betaq = pow ((1.0/(2.0 - rand*alpha)),(1.0/(eta_c+1.0)));
                    }
                    c22 = 0.5*((y1+y2)+betaq*(y2-y1));
                    if (c11<yl)
                        c11=yl;
                    if (c22<yl)
                        c22=yl;
                    if (c11>yu)
                        c11=yu;
                    if (c22>yu)
                        c22=yu;
                    if (rnd_uni(&rnd_uni_init)<=0.5)
                    {
                        child1.x_var[i] = c22;
                        child2.x_var[i] = c11;
                    }
                    else
                    {
                        child1.x_var[i] = c11;
                        child2.x_var[i] = c22;
                    }
                }
                else
                {
                    child1.x_var[i] = parent1.x_var[i];
                    child2.x_var[i] = parent2.x_var[i];
                }
            }
            else
            {
                child1.x_var[i] = parent1.x_var[i];
                child2.x_var[i] = parent2.x_var[i];
            }
        }
    }
    else
    {
        for (int i=0; i<nvar; i++)
        {
            child1.x_var[i] = parent1.x_var[i];
            child2.x_var[i] = parent2.x_var[i];
        }
    }
    return;
}

void real_sbx_xoverB (CIndividual &parent1, CIndividual &parent2, CIndividual &child)
{
    double rand;
    double y1, y2, yl, yu;
    double c11, c22;
    double alpha, beta, betaq;
	double eta_c = etax;
	//eta_c = 0.5;
    if (rnd_uni(&rnd_uni_init) <= 1.0) 
    {
        for (int i=0; i<nvar; i++)
        {
            if (rnd_uni(&rnd_uni_init)<=0.5 )
            {
                if (fabs(parent1.x_var[i]-parent2.x_var[i]) > EPS)
                {
                    if (parent1.x_var[i] < parent2.x_var[i])
                    {
                        y1 = parent1.x_var[i];
                        y2 = parent2.x_var[i];
                    }
                    else
                    {
                        y1 = parent2.x_var[i];
                        y2 = parent1.x_var[i];
                    }
                    yl = lowBound[i];
                    yu = uppBound[i];
                    rand = rnd_uni(&rnd_uni_init);
                    beta = 1.0 + (2.0*(y1-yl)/(y2-y1));
                    alpha = 2.0 - pow(beta,-(eta_c+1.0));
                    if (rand <= (1.0/alpha))
                    {
                        betaq = pow ((rand*alpha),(1.0/(eta_c+1.0)));
                    }
                    else
                    {
                        betaq = pow ((1.0/(2.0 - rand*alpha)),(1.0/(eta_c+1.0)));
                    }
                    c11 = 0.5*((y1+y2)-betaq*(y2-y1));
                    beta = 1.0 + (2.0*(yu-y2)/(y2-y1));
                    alpha = 2.0 - pow(beta,-(eta_c+1.0));
                    if (rand <= (1.0/alpha))
                    {
                        betaq = pow ((rand*alpha),(1.0/(eta_c+1.0)));
                    }
                    else
                    {
                        betaq = pow ((1.0/(2.0 - rand*alpha)),(1.0/(eta_c+1.0)));
                    }
                    c22 = 0.5*((y1+y2)+betaq*(y2-y1));
                    if (c11<yl)
					{
                        double rnd = rnd_uni(&rnd_uni_init);
						c11=yl+rnd*(y1-yl);						
					}
                    if (c22<yl)
					{
                        double rnd = rnd_uni(&rnd_uni_init);
						c22=yl+rnd*(y2-yl);						
					}
                    if (c11>yu)
					{                        
						double rnd = rnd_uni(&rnd_uni_init);
						c11=yu-rnd*(yu-y1);
					}
                    if (c22>yu)
					{
                        double rnd = rnd_uni(&rnd_uni_init);
						c22=yu-rnd*(yu-y2);
					}
                    if (rnd_uni(&rnd_uni_init)<=0.5)
                    {
                        child.x_var[i] = c22;
                    }
                    else
                    {
                        child.x_var[i] = c11;
                    }
                }
                else
                {
                    child.x_var[i] = parent1.x_var[i];
                }
            }
            else
            {
                child.x_var[i] = parent1.x_var[i];
            }
        }
    }
    else
    {
        for (int i=0; i<nvar; i++)
        {
            child.x_var[i] = parent1.x_var[i];
        }
    }
    return;
}

void real_sbx_xoverB (CIndividual &parent1, CIndividual &parent2, CIndividual & Original, CIndividual &child, vector<int> indexes)
{
	int i,j;
    double rand;
    double y1, y2, yl, yu;
    double c11, c22;
    double alpha, beta, betaq;
	double eta_c = etax;
	//eta_c = 0.5;
    if (rnd_uni(&rnd_uni_init) <= 1.0) 
    {
        for (i=0; i<nvar; i++)
        {
			for (j=0; j<indexes.size() && i!= indexes[j]; j++) {}
			if (j<indexes.size())
            {
                if (fabs(parent1.x_var[i]-parent2.x_var[i]) > EPS)
                {
                    if (parent1.x_var[i] < parent2.x_var[i])
                    {
                        y1 = parent1.x_var[i];
                        y2 = parent2.x_var[i];
                    }
                    else
                    {
                        y1 = parent2.x_var[i];
                        y2 = parent1.x_var[i];
                    }
                    yl = lowBound[i];
                    yu = uppBound[i];
                    rand = rnd_uni(&rnd_uni_init);
                    beta = 1.0 + (2.0*(y1-yl)/(y2-y1));
                    alpha = 2.0 - pow(beta,-(eta_c+1.0));
                    if (rand <= (1.0/alpha))
                    {
                        betaq = pow ((rand*alpha),(1.0/(eta_c+1.0)));
                    }
                    else
                    {
                        betaq = pow ((1.0/(2.0 - rand*alpha)),(1.0/(eta_c+1.0)));
                    }
                    c11 = 0.5*((y1+y2)-betaq*(y2-y1));
                    beta = 1.0 + (2.0*(yu-y2)/(y2-y1));
                    alpha = 2.0 - pow(beta,-(eta_c+1.0));
                    if (rand <= (1.0/alpha))
                    {
                        betaq = pow ((rand*alpha),(1.0/(eta_c+1.0)));
                    }
                    else
                    {
                        betaq = pow ((1.0/(2.0 - rand*alpha)),(1.0/(eta_c+1.0)));
                    }
                    c22 = 0.5*((y1+y2)+betaq*(y2-y1));
                    if (c11<yl)
					{
                        double rnd = rnd_uni(&rnd_uni_init);
						c11=yl+rnd*(y1-yl);						
					}
                    if (c22<yl)
					{
                        double rnd = rnd_uni(&rnd_uni_init);
						c22=yl+rnd*(y2-yl);						
					}
                    if (c11>yu)
					{                        
						double rnd = rnd_uni(&rnd_uni_init);
						c11=yu-rnd*(yu-y1);
					}
                    if (c22>yu)
					{
                        double rnd = rnd_uni(&rnd_uni_init);
						c22=yu-rnd*(yu-y2);
					}
                    if (rnd_uni(&rnd_uni_init)<=0.5)
                    {
                        child.x_var[i] = c22;
                    }
                    else
                    {
                        child.x_var[i] = c11;
                    }
                }
                else
                {
                    child.x_var[i] = Original.x_var[i];
                }
            }
            else
            {
                child.x_var[i] = Original.x_var[i];
            }
        }
    }
    else
    {
        for (int i=0; i<nvar; i++)
        {
            child.x_var[i] = Original.x_var[i];
        }
    }
    return;
}

void diff_evo_xoverA(CIndividual &ind0, CIndividual &ind1, CIndividual &ind2, CIndividual &ind3, CIndividual &child, double rate)
{

	// Check Whether the cross-over to be performed
	/*Loop over no of variables*/
	int idx_rnd = int(rnd_uni(&rnd_uni_init)*nvar);
	
	//rate = rnd_uni(&rnd_uni_init);
	for(int n=0;n<nvar;n++)
	{
	  double rnd = rnd_uni(&rnd_uni_init);
	  if(rnd<1||n==idx_rnd)
		  child.x_var[n] = ind1.x_var[n] + rate*(ind2.x_var[n] - ind3.x_var[n]);
	  else
		  child.x_var[n] = ind0.x_var[n];

	  if(child.x_var[n]<lowBound[n]) child.x_var[n] = lowBound[n];
	  if(child.x_var[n]>uppBound[n]) child.x_var[n] = uppBound[n];
	}
}

void diff_evo_xoverB(CIndividual &ind0, CIndividual &ind1, CIndividual &ind2, CIndividual &child, double rate)
{
	int idx_rnd = int(rnd_uni(&rnd_uni_init)*nvar);
	rate = rnd_uni(&rnd_uni_init);

	for(int n=0;n<nvar;n++)	{
	  double rnd1 = rnd_uni(&rnd_uni_init);
	  double CR   = 1.0;
	  if(rnd1<CR||n==idx_rnd)
		  child.x_var[n] = ind0.x_var[n] + rate*(ind2.x_var[n] - ind1.x_var[n]);
	  else
		  child.x_var[n] = ind0.x_var[n];
	  // handle the boundary voilation
	  if(child.x_var[n]<lowBound[n]){
		  double rnd = rnd_uni(&rnd_uni_init);
		  child.x_var[n] = lowBound[n] + rnd*(ind0.x_var[n] - lowBound[n]);
	  }
	  if(child.x_var[n]>uppBound[n]){ 
		  double rnd = rnd_uni(&rnd_uni_init);
		  child.x_var[n] = uppBound[n] - rnd*(uppBound[n] - ind0.x_var[n]);
	  }
	}
}

void diff_evo_xoverB(CIndividual &ind0, CIndividual &ind1, CIndividual &ind2, CIndividual &child, double rate,vector<int> &indices)
{
	int idx_rnd = int(rnd_uni(&rnd_uni_init)*nvar);
	//rate = rnd_uni(&rnd_uni_init);

	child.x_var =  ind0.x_var;

	for(int n=0; n<indices.size(); n++)	{
	  double rnd1 = rnd_uni(&rnd_uni_init);
	  double CR   = 1.0;
	  if(rnd1<CR||n==idx_rnd)		  child.x_var[indices[n]] = ind0.x_var[indices[n]] + rate*(ind2.x_var[indices[n]] - ind1.x_var[indices[n]]);
	  else		  child.x_var[indices[n]] = ind0.x_var[indices[n]];
	  // handle the boundary voilation
	  if(child.x_var[indices[n]]<lowBound[indices[n]]){
		  double rnd = rnd_uni(&rnd_uni_init);
		  child.x_var[indices[n]] = lowBound[indices[n]] + rnd*(ind0.x_var[indices[n]] - lowBound[indices[n]]);
	  }
	  if(child.x_var[indices[n]]>uppBound[indices[n]]){ 
		  double rnd = rnd_uni(&rnd_uni_init);
		  child.x_var[indices[n]] = uppBound[indices[n]] - rnd*(uppBound[indices[n]] - ind0.x_var[indices[n]]);
	  }
	}//end for n
}

void diff_evo_xoverC(CIndividual &ind0, CIndividual &ind1, CIndividual &ind2, vector<double> &xdiff,  CIndividual &child,  double rate)
{
      double rnd = rnd_uni(&rnd_uni_init), rnd2 = rnd_uni(&rnd_uni_init);
	  for(int n=0;n<nvar;n++)
	  {
		  /*Selected Two Parents*/
		  
		  if(rnd<1)
		      child.x_var[n] = ind0.x_var[n] + rate*(ind2.x_var[n] - ind1.x_var[n]);
		  else
			  child.x_var[n] = ind0.x_var[n] + rnd2*xdiff[n];
	
		  if(child.x_var[n]<lowBound[n]) child.x_var[n] = lowBound[n];
		  if(child.x_var[n]>uppBound[n]) child.x_var[n] = uppBound[n];
	  }
}

#endif