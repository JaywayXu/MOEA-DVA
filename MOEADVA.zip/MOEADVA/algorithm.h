#ifndef __EVOLUTION_H_
#define __EVOLUTION_H_

#include "global.h"
#include "recomb.h"
#include "common.h"
#include "individual.h"

class CMOEAD
{
public:
	CMOEAD();
	virtual ~CMOEAD();

	void update_neighbour_table(int type);             // calculate the neighbourhood of each subproblem
	void init_population();                    // initialize the population
	void load_parameter();
	void update_reference(CIndividual &ind);					// update ideal point which is used in Tchebycheff or NBI method
	void update_nadpoint();						
	void tour_selection(int depth, vector<int> &selected);
	void update_problem(CIndividual &ind, int &id, int &type);	// update current solutions in the neighbourhood
	void evol_population_subcomponent(vector<int> &indices);       // DE-based recombination
	void evol_population_MOEAD();  
	void TransmitInformationSubMOPToSubproblem();
	void mate_selection(vector<int> &list, int cid, int size, int type);  // select mating parents
	void comp_utility();
	double Total_utility();
	// execute MOEAD
	void exec_emo(int run);
	void ControlVariableAnalysis(); 
	void DecisionVariableAnalysis();
	void InterdependenceAnalysis();
	void DependentVariableAnalysis();
	void VariableGroup();
	void save_front(char savefilename[1024]);       // save the pareto front into files
	void save_pos(char savefilename[1024]);

    vector <CSubproblem> population;
	vector <CIndividual> TempPopulation;
public:	// algorithm parameters
	int		max_gen;
	int     pops;          //  the population size
    int	    niche;         //  the neighborhood size
	int     limit;         //  the maximal number of solutions replaced
	double  prob;          //  the neighboring selection probability
	double  rate;          //  the differential rate between solutions
	int     nfes;          //  the number of function evluations
};

CMOEAD::CMOEAD() {}

CMOEAD::~CMOEAD(){
	population.clear();
}


void CMOEAD::init_population()
{
	int i,j;
	idealpoint = vector<double>(nobj, 1.0e+30);
	nad_point = vector<double>(nobj, -1.0e+30);

	char filename[1024];		
	sprintf(filename,"ParameterSetting/Weight/W%dD_%d.dat", nobj, pops);// Read weight vectors from a data file
	std::ifstream readf(filename);
	for(i=0; i<pops; i++)	{
		CSubproblem sub;		
		for(int j=0; j<nobj; j++)	readf>>sub.namda[j];// Load weight vectors
		population.push_back(sub);
	}	
	readf.close();
	//line 2 of Algorithm 5: MOEA/DVA.
	if (DiversityIndexs.size() == 1){// if the Pareto set is m-1 dimension, the problem is 2-objective problem. Where m is the number of objective functions of MOP.
		int ind = DiversityIndexs[0];
		for (i=0; i<population.size(); i++) {
			population[i].indiv.x_var[ind]=lowBound[ind] + i*1.0/(pops-1) * (uppBound[ind]-lowBound[ind]);
			population[i].positionFactor=vector<double>(DiversityIndexs.size(), 0.0);
			population[i].positionFactor[0] = i*1.0/(pops-1);
		}
	}
	else if (DiversityIndexs.size() >= 2 && DiversityIndexs.size() <= 4) {// if the Pareto set is m-1 dimension, the problem is 3-objective problem. 
		sprintf(filename,"generate uniform points on supercube/SamplePoint_Dim%dN120.txt",DiversityIndexs.size());
		std::ifstream readf(filename);
		double tempValue;
		for (i=0; i<120; i++)	{
			population[i].positionFactor=vector<double>(DiversityIndexs.size(), 0.0);
			for (j=0; j<DiversityIndexs.size(); j++) 	{
				int ind = DiversityIndexs[j];
				double temp;
				readf>>temp;
				population[i].indiv.x_var[ind] = lowBound[ind] + temp * (uppBound[ind]-lowBound[ind]);
				population[i].positionFactor[j] = population[i].indiv.x_var[ind];
			}			
		}
		readf.close();
	}
	else if (DiversityIndexs.size() >= 5) {
		 for (i=0; i<population.size(); i++)	{
			population[i].positionFactor=vector<double>(DiversityIndexs.size(), 0.0);
			for (j=0; j<DiversityIndexs.size(); j++) 	{
				int ind = DiversityIndexs[j];
				population[i].indiv.x_var[ind] = lowBound[ind] + rnd_uni(&rnd_uni_init) * (uppBound[ind]-lowBound[ind]);
				population[i].positionFactor[j] = population[i].indiv.x_var[ind];
			}			
		}
	} // if the Pareto set is m-1 dimension, the problem is many-objective problem.
	// line 3 of Algorithm 5:MOEA/DVA:  ramdomly initialize the variables controling the convergence for each individual
	for (i=0; i<population.size(); i++)	{
		for (j=0; j<ConvergenceIndexs.size(); j++) {
			int ind = ConvergenceIndexs[j];
			population[i].indiv.x_var[ind] = lowBound[ind] + rnd_uni(&rnd_uni_init) * (uppBound[ind]-lowBound[ind]);
		}
		population[i].indiv.obj_eval(); 
		nfes++;
		population[i].saved = population[i].indiv;		
		update_reference(population[i].indiv); // update the reference point
	}

	update_neighbour_table(1); 

	if (!strcmp("_TCH2",strFunctionType) || !strcmp("_MTCH2",strFunctionType)) 
		update_nadpoint();
}

void CMOEAD::update_neighbour_table(int type) 
{   //type = 0: weight vector
	//type = 1: diverse variable
	int i,j,k;
	//1. update the neighbour individual
	vector<double> dist   = vector<double>(population.size(), 0);
	vector<int>    indxxx   = vector<int>(population.size(), 0);

	for (i = 0; i < population.size(); i++)		population[i].table.clear();
	for (i = 0; i < population.size(); i++)	{			
		for(j=0; j<population.size(); j++)		{ // calculate the distances based on position factors
			if (type == 1) dist[j]    = dist_vector(population[i].positionFactor,population[j].positionFactor);
			else dist[j]    = dist_vector(population[i].namda,population[j].namda);
			indxxx[j]  = j;
		}		
		minfastsort(dist,indxxx,population.size(),niche);// find 'niche' nearest neighboring subproblems
		// save the indexes of the nearest 'niche' neighboring position factors
		for(int k=0; k<niche; k++)	population[i].table.push_back(indxxx[k]);
	}	
	dist.clear();	indxxx.clear();
}

void CMOEAD::update_reference(CIndividual &ind)
{	//ind: child solution
	for(int n=0; n<nobj; n++)	{
		if(ind.y_obj[n]<idealpoint[n])		{
			idealpoint[n] = ind.y_obj[n];
		}
	}
}

void CMOEAD::update_nadpoint()
{
	int i,j;
	double temp_low  = -1.0e30;
	for (j=0; j < nobj; j++)	{
		temp_low  = -1e30;
		for (i=0; i < population.size(); i++)		{
			if (temp_low < population[i].indiv.y_obj[j])
				temp_low = population[i].indiv.y_obj[j];
		}
		nad_point[j] = temp_low;
	}
}

void CMOEAD::mate_selection(vector<int> &list, int cid, int size, int type){
	int ss   = population[cid].table.size(), id, parent;
    while(list.size()<size)	{
		if(type==1){
		    id      = int(ss*rnd_uni(&rnd_uni_init));
			parent  = population[cid].table[id];
		}
		else	parent  = int(population.size()*rnd_uni(&rnd_uni_init));
		// avoid the repeated selection
		bool flag = true;
		for(int i=0; i<list.size(); i++)		{
			if(list[i]==parent) 			{
				flag = false;
				break;
			}
		}
		if(flag) list.push_back(parent);
	}
}

void CMOEAD::comp_utility()
{
	double f1, f2, uti, delta;
    for(int n=0; n<pops; n++)	{
		f1 = fitnessfunction(population[n].indiv.y_obj, population[n].namda);
		f2 = fitnessfunction(population[n].saved.y_obj, population[n].namda);
		delta = f2 - f1;
        if(delta>0.001)  population[n].utility = 1.0;
		else{
			population[n].utility = (0.95+0.05*delta/0.001)*population[n].utility;
		}
        population[n].saved = population[n].indiv;
	}
}

void CMOEAD::tour_selection(int depth, vector<int> &selected)
{
	// selection based on utility
	vector<int> candidate;
	for(int k=0;    k<nobj; k++)    selected.push_back(k);   // select first m weights
	for(int n=nobj; n<pops; n++)    candidate.push_back(n);  // set of unselected weights

	while(selected.size()<int(pops/5.0))	{
	    int best_idd = int(rnd_uni(&rnd_uni_init)*candidate.size()), i2;
		int best_sub = candidate[best_idd], s2;
		for(int i=1; i<depth; i++)		{
		    i2  = int(rnd_uni(&rnd_uni_init)*candidate.size());
			s2  = candidate[i2];
			if(population[s2].utility>population[best_sub].utility)			{
				best_idd = i2;
			    best_sub = s2;
			}
		}
		selected.push_back(best_sub);
		candidate.erase(candidate.begin()+best_idd);
	}
	candidate.clear();
}

//Algorithm 1 of MOEA/DVA
void CMOEAD::ControlVariableAnalysis() 
{	// Analyze the decision variable control the convergence or spread aspects 
    //distance parameter,  position parameter or mixed parameter.
	int i,j;
	Control.clear();
	for (i=0; i<nvar; i++) Control.push_back(-2);
	for (i=0; i<nvar; i++) {
		CIndividual RandomIndiv;
		RandomIndiv.rnd_init(); 	
		for (j = 0; j < S.size(); j++)		S[j].clear();
		S.clear();
		for (j=0; j<NumControlAnalysis; j++) {
			RandomIndiv.x_var[i] = ( j + rnd_uni(&rnd_uni_init) )  / NumControlAnalysis;
			RandomIndiv.obj_eval();	nfes++;
			S.push_back(RandomIndiv.y_obj);
		} //end for j
		Control[i] = dominate(S);
	}//end for i
	// statistics the variables which control the diversity or/and convergence.
	DiversityIndexs.clear(); ConvergenceIndexs.clear();
	for (i=0; i<nvar; i++)	{
		if (Control[i] == 0 || Control[i] == -1) DiversityIndexs.push_back(i);
		else ConvergenceIndexs.push_back(i);
	}
}
//Algorithm 2 of MOEA/DVA
void CMOEAD::InterdependenceAnalysis()
{	//Analyze the dependent relationship among the decision variables.
	int i,j,l,k;
	Dependent.clear();
	for (l=0; l<Dependent.size(); l++) {
		for (i = 0; i < Dependent[l].size(); i++)		Dependent[l][i].clear();
		Dependent[l].clear();
	}
	Dependent.clear();
	for (l=0; l<nobj; l++) {
		Dependent.push_back(vector <vector<int> > (0));
		for (i=0; i<nvar; i++)	{
			Dependent[l].push_back(vector <int> (0));
			for (j=0; j<nvar; j++) Dependent[l][i].push_back(0);
		}
	}

	CIndividual ind_a1_b1, ind_a2_b1, ind_a1_b2, ind_a2_b2;
	for (i=0; i<nvar; i++) {
		for (j=i+1; j<nvar; j++) {
			for (k=0; k<NumIndependentAnalysis; k++) {
				//generate another three solution ind(...a2,...,b1,...), ind(...a1,...,b2,...), ind(...a2,...,b2,...).					
				int SeleIndivIndex = int( population.size() * rnd_uni(&rnd_uni_init) );
				ind_a1_b1 = population[SeleIndivIndex].indiv;
				ind_a2_b1=ind_a1_b1; ind_a1_b2=ind_a1_b1; ind_a2_b2=ind_a1_b1;//initialize 
				double a2=lowBound[i] + rnd_uni(&rnd_uni_init)*(uppBound[i] - lowBound[i]);
				while ( fabs(a2 - ind_a1_b1.x_var[i]) < (uppBound[i]-lowBound[i])/100 ) 
					a2=lowBound[i] + rnd_uni(&rnd_uni_init)*(uppBound[i] - lowBound[i]);
				double b2=lowBound[j] + rnd_uni(&rnd_uni_init)*(uppBound[j] - lowBound[j]);
				while ( fabs(b2 - ind_a1_b1.x_var[j]) < (uppBound[i]-lowBound[i])/100 ) 
					b2=lowBound[j] + rnd_uni(&rnd_uni_init)*(uppBound[j] - lowBound[j]);
				ind_a2_b1.x_var[i] = a2;		ind_a2_b1.obj_eval(); nfes++;
				ind_a1_b2.x_var[j] = b2;		ind_a1_b2.obj_eval(); nfes++;
				ind_a2_b2.x_var[i] = a2; 
				ind_a2_b2.x_var[j] = b2;		ind_a2_b2.obj_eval(); nfes++;
				for (l=0; l<nobj; l++){
					double temp1 = (ind_a2_b1.y_obj[l] - ind_a1_b1.y_obj[l]) * (ind_a2_b2.y_obj[l] - ind_a1_b2.y_obj[l]);
					double temp2 = (ind_a1_b2.y_obj[l] - ind_a1_b1.y_obj[l]) * (ind_a2_b2.y_obj[l] - ind_a2_b1.y_obj[l]);
					if ( temp1 < 0 || temp2 < 0 ) Dependent[l][i][j]=Dependent[l][j][i]=1; // variable x_i has a depentant relationship with x_j.								
				}
				if ( IsDistanceVariable(j) && UpdateSolution(population[SeleIndivIndex].indiv.y_obj, ind_a1_b2.y_obj) ) {
					population[SeleIndivIndex].indiv.x_var[j] = b2;
					population[SeleIndivIndex].indiv.y_obj = ind_a1_b2.y_obj;
				}
				if ( IsDistanceVariable(i) && UpdateSolution(population[SeleIndivIndex].indiv.y_obj, ind_a2_b1.y_obj) ) {
					population[SeleIndivIndex].indiv.x_var[i] = a2;
					population[SeleIndivIndex].indiv.x_var[j] = ind_a1_b1.x_var[j];
					population[SeleIndivIndex].indiv.y_obj = ind_a2_b1.y_obj;
				}
				if ( IsDistanceVariable(i) && IsDistanceVariable(j) && UpdateSolution(population[SeleIndivIndex].indiv.y_obj, ind_a2_b2.y_obj) ) {
					population[SeleIndivIndex].indiv.x_var[i] = a2;
					population[SeleIndivIndex].indiv.x_var[j] = b2;
					population[SeleIndivIndex].indiv.y_obj = ind_a2_b2.y_obj;
				}
			}
		}
	}
}
//Algorithm 3 of MOEA/DVA
void CMOEAD::DependentVariableAnalysis()
{	// Analyze whether a decision varialbe is effective for individual function.
	int i,j,l;
	for (l=0; l < Effect.size(); l++) Effect[l].clear();
	Effect.clear();
	for (l=0; l < nobj; l++) Effect.push_back( vector<int>(nvar, 0) );
	CIndividual RandIndiv;
	for (i=0; i < nvar; i++) { 
		int SeleIndivIndex = int( population.size() * rnd_uni(&rnd_uni_init) );
		RandIndiv = population[SeleIndivIndex].indiv;
		for (j=0; j < NumDependentAnalysis; j++) {
			RandIndiv.x_var[i] = ( j + rnd_uni(&rnd_uni_init) ) / NumDependentAnalysis;
			RandIndiv.obj_eval(); nfes++;
			for (l=0; l < nobj; l++) {
				if ( fabs(population[SeleIndivIndex].indiv.y_obj[l] - RandIndiv.y_obj[l]) > 1e-20 ) Effect[l][i]=1;
			}
			if ( IsDistanceVariable(i) && UpdateSolution(population[SeleIndivIndex].indiv.y_obj, RandIndiv.y_obj) ) {
				population[SeleIndivIndex].indiv.x_var[i] = RandIndiv.x_var[i];
				population[SeleIndivIndex].indiv.y_obj = RandIndiv.y_obj;
			}
		}
	}	
}
//Algorithm 4 of MOEA/DVA: Grouping decision variable based on linkage on all the objective functions
//to decompose distance variables
void CMOEAD::VariableGroup()
{
	int i,j,k;

	InterdependenceAnalysis();
	DependentVariableAnalysis();

	for (i=0; i<Groups.size(); i++) Groups[i].clear();
	Groups.clear();
	vector<int> cluster;
	vector<int> TmpConverIndex(ConvergenceIndexs);	//MOEA/DVA just consider the linkages between distance variables to group variable.
	while (TmpConverIndex.size() > 0) {
		cluster.push_back(TmpConverIndex[0]);
		TmpConverIndex.erase(TmpConverIndex.begin());
		for (i=0; i<cluster.size(); i++) {
			for (j=0; j<TmpConverIndex.size(); j++) { //just consider  the linkages between distance variables
				for (k=0; k<nobj; k++) { //consider the linkage in all of objective functions
					if (Dependent[k][cluster[i]][TmpConverIndex[j]] == 1) {
						cluster.push_back(TmpConverIndex[j]);
						TmpConverIndex.erase(TmpConverIndex.begin() + j);
						j--;
						break;
					}
				}
			}
		}
		Groups.push_back(cluster);
		cluster.clear();
	}
}

void CMOEAD::update_problem(CIndividual &indiv, int &id, int &type)
{
	int i,j,k;
	int size, time = 0;	
	vector<bool> flag=vector<bool>(population.size(), true);
    //-----------------------------------------------------------//
	if(type==1)	size = population[id].table.size();  // from neighborhood
	else        size = population.size();            // from whole population
	// a random order to update
	std::vector<int> perm(std::vector<int>(size, 0));
	for(k=0; k<size; k++) perm[k] = k;
	random_shuffle(perm.begin(), perm.end());

    for(i=0; i<size; i++)	{
		// Pick a subproblem to update
		if(type==1) k = population[id].table[perm[i]];
		else        k = perm[i];
		flag[k] = false;
		// calculate the values of objective function regarding the current subproblem
		double f1, f2;
		f1 = fitnessfunction(population[k].indiv.y_obj, population[k].namda);
		f2 = fitnessfunction(indiv.y_obj, population[k].namda);
		if(f2<f1)		{
			population[k].indiv = indiv;
			time++;
		}
		// the maximal number of solutions updated is not allowed to exceed 'limit'
		if(time>=limit)		{
			flag.clear();
			perm.clear();
			return;
		}
	}
	//------consider such case: if &indiv can not update its neighbour,while it can update other subpreblems-----------//
	if (type == 1)
	{	// a random order to update
		std::vector<int> perm2(std::vector<int>(population.size(), 0));
		for(k=0; k<size; k++) perm2[k] = k;
		random_shuffle(perm2.begin(), perm2.end());
		for(i=0; i<population.size(); i++)		{
			int k = perm2[i];
			if (flag[k] == true)			{
				double f1, f2;
				f1 = fitnessfunction(population[k].indiv.y_obj, population[k].namda);
				f2 = fitnessfunction(indiv.y_obj, population[k].namda);
				if(f2<f1)				{
					population[k].indiv = indiv;
					time++;
				}
				// the maximal number of solutions updated is not allowed to exceed 'limit'
				if(time>=limit)				{
					flag.clear();
					perm2.clear();
					return;
				}
			}
		}
		perm2.clear();
	}

	flag.clear();
	perm.clear();
}

void CMOEAD::evol_population_MOEAD()
{
	vector<int> order;	this->tour_selection(10, order);
    for(int sub=0; sub<order.size(); sub++)	{
		int c_sub = order[sub];    // random order
		int type;
        double rnd = rnd_uni(&rnd_uni_init);
		// mating selection based on probability
		if(rnd<prob)     type = 1;   // from neighborhood
		else             type = 2;   // from population
		// select the indexes of mating parents
		vector<int> plist;
		mate_selection(plist, c_sub, 2, type);  // neighborhood selection
		// produce a child solution
		CIndividual child;
		if (!strcmp("SBX",strCrossType))		{
			real_sbx_xoverB(population[plist[0]].indiv,population[plist[1]].indiv,child);
		}
		else		{
			double rate2 = 0.5; //rate + 0.25*(rnd_uni(&rnd_uni_init) - 0.5);
			diff_evo_xoverB(population[c_sub].indiv,population[plist[0]].indiv,population[plist[1]].indiv, child, rate2);
		}		
		plist.clear();	
		// apply polynomial mutation
		realmutation(child, 1.0/nvar);
		// evaluate the child solution
		child.obj_eval();
		// update the reference points and other solutions in the neighborhood or the whole population
		update_reference(child);
		update_problem(child, c_sub, type);
		nfes++;
	}
	if (!strcmp("_TCH2",strFunctionType)) 
		update_nadpoint();
	order.clear();
}

//Algorithm 6 of MOEA/DVA: subcomponent optimization
void CMOEAD::evol_population_subcomponent(vector<int> &indices) 
{
	for (int i = 0; i<population.size(); i++)	{
		int type;
		// mating selection based on probability
		if (rnd_uni(&rnd_uni_init)<prob)     type = 1;   // from neighborhood
		else             type = 2;   // from population
		// select the indexes of mating parents
		vector<int> plist;
		mate_selection(plist, i, 2, type);  // neighborhood selection
		// setp 1 of algorithm 6: produce a child solution
		CIndividual child;
		if (!strcmp("SBX",strCrossType))		{
			real_sbx_xoverB(population[plist[0]].indiv,population[plist[1]].indiv,population[i].indiv,child,indices);
		}
		else	{
			double rate2 = 0.5; //rate + 0.25*(rnd_uni(&rnd_uni_init) - 0.5);
			diff_evo_xoverB(population[i].indiv,population[plist[0]].indiv,population[plist[1]].indiv, child, rate2,indices);
		}		
		plist.clear();	
		// apply polynomial mutation
		realmutation(child, 1.0 / ( nvar * indices.size() ), indices);
		// evaluate the child solution
		child.obj_eval(); nfes++;
		update_reference(child);
		if ( UpdateSolution(population[i].indiv.y_obj,child.y_obj) ) population[i].indiv = child; //step 3 of Algorithm 6
	}
	if (!strcmp("_TCH2",strFunctionType)  || !strcmp("_MTCH2",strFunctionType)) 
		update_nadpoint();
}

double CMOEAD::Total_utility()
{
	double utility = 0.0,f1,f2,delta;
	for (int n=0; n<population.size();n++) {
		f1 = fitnessfunction(population[n].indiv.y_obj, population[n].namda);
		f2 = fitnessfunction(population[n].saved.y_obj, population[n].namda);
		if (f1<f2) utility += f2-f1;
        population[n].saved = population[n].indiv;
	}
	return utility/population.size();
}

void CMOEAD::TransmitInformationSubMOPToSubproblem() 
{
	int i,j;
	vector<CIndividual> TempPopulation;
	for (i=0; i < population.size(); i++) TempPopulation.push_back(population[i].indiv);
	vector <int> RestPopList, RestTempPopList, DelPopInd, DelTmpPopInd;
	vector <vector<int> > IndexList;
	vector <vector<double> > ValueList;
	for (i=0; i<population.size(); i++) RestPopList.push_back(i);
	for (i=0; i<TempPopulation.size(); i++) RestTempPopList.push_back(i);
	while (RestPopList.size() > 0) {
		for (i=0; i<IndexList.size(); i++) IndexList[i].clear();
		IndexList.clear();
		for (i=0; i<RestPopList.size(); i++) IndexList.push_back(vector<int>(0));
		for (i=0; i<ValueList.size(); i++) ValueList[i].clear();
		ValueList.clear();
		for (i=0; i<RestPopList.size(); i++) ValueList.push_back(vector<double>(0));
		//1. for each member in rest TempPopulation, calculate its optimal subproblem 
		for (i=0; i<RestTempPopList.size(); i++) {
			int indTmpPop = RestTempPopList[i];
			int PopListMinInd = -1;
			double Minvalue = 1.0e30;
			for (j=0; j<RestPopList.size(); j++) {
				int indPop = RestPopList[j];
				double f1 = fitnessfunction(TempPopulation[indTmpPop].y_obj, population[indPop].namda);
				if (f1 < Minvalue) { Minvalue = f1; PopListMinInd=j;	}
			}// end for j
			IndexList[PopListMinInd].push_back(i);
			ValueList[PopListMinInd].push_back(Minvalue);
		}// end for i
		//2. for each member in rest population, select a suitable solution from its candidates
		DelPopInd.clear();
		DelTmpPopInd.clear();
		for (i=0; i<RestPopList.size(); i++){
			int indPop = RestPopList[i];
			int indexRPLMin = -1; 
			double valueMin = 1.0e30;
			for (j=0; j < IndexList[i].size(); j++){
				if (ValueList[i][j]<valueMin) {
					indexRPLMin =j; 
					valueMin = ValueList[i][j];
				}
			}// end for j
			if (indexRPLMin >= 0) {
				int indTmpPopList = IndexList[i][indexRPLMin];
				int indTmpPop = RestTempPopList[indTmpPopList];
				for (j=0; j<DiversityIndexs.size(); j++) 
					population[indPop].indiv=TempPopulation[indTmpPop];
				DelPopInd.push_back(i);
				DelTmpPopInd.push_back(indTmpPopList);
			}
		}// end for i
		// 3. Delete the partners from RestPopList and RestTempPopList
		bubbleSort(DelPopInd);
		for (i = DelPopInd.size()-1; i>=0; i--) RestPopList.erase(RestPopList.begin() + DelPopInd[i]);
		bubbleSort(DelTmpPopInd);
		for (i = DelTmpPopInd.size()-1; i>=0; i--) RestTempPopList.erase(RestTempPopList.begin() + DelTmpPopInd[i]);
	}//end while

	update_neighbour_table(0);//update the neighborhood
}

void CMOEAD::exec_emo(int run) 
{
	//initialize the random seed.
    char filename[1024];
	seed = (seed + 23)%1377;
	rnd_uni_init = -(long)seed;
	// initialization
	nfes      = 0;
	strcpy(strUpdateSolutionMode,"ValueSum");
	//prob = 1;	
	ControlVariableAnalysis();	//line 1 of Algorithm 5: MOEA/DVA
	init_population(); //lines 2-3 of Algorithm 5: MOEA/DVA
	VariableGroup(); // line 4 of Algorithm 5: MOEA/DVA: get the groups  of decision variables.
	// evolution
	int cur_gen = 0, gen = 0;
	double utility=1.0e3,threshold;
	if (nobj==2) threshold = 0.01;
	else threshold = 0.03;
	while(nfes<num_max_evulation && utility>threshold)	 {				
		//for output the intermediate solutions in the evolutionary population
		if (nfes >= cur_gen*num_max_evulation/30)		{
			sprintf(filename,"POF/%d/POF_MOEADVA_%s_OBJ%d_RUN%d.txt", cur_gen*10,strTestInstance, nobj, run);
			save_front(filename);
			sprintf(filename,"POS/%d/POS_MOEADVA_%s_OBJ%d_RUN%d.txt", cur_gen*10,strTestInstance, nobj, run);
			save_pos(filename);
			cur_gen++;
		}
		for (int j=0; j < Groups.size(); j++)  evol_population_subcomponent(Groups[j]);	//line 8-11 of Algorithm 5:MOEA/DVA
		gen++;
		if(gen%2==0)    utility = Total_utility();
	}

    TransmitInformationSubMOPToSubproblem();
	gen = 1;
	while (nfes<num_max_evulation) {
		if (nfes >= cur_gen*num_max_evulation/30)		{
			sprintf(filename,"POF/%d/POF_MOEADVA_%s_OBJ%d_RUN%d.txt", cur_gen*10,strTestInstance, nobj, run);
			save_front(filename);
			sprintf(filename,"POS/%d/POS_MOEADVA_%s_OBJ%d_RUN%d.txt", cur_gen*10,strTestInstance, nobj, run);
			save_pos(filename);
			cur_gen++;
		}

		if(gen%30==0)    comp_utility();
		evol_population_MOEAD();
	}
	// save the found solutions in evolutionary population
	sprintf(filename,"POS/POS_MOEADVA_%s_OBJ%d_RUN%d.txt",strTestInstance, nobj, run);
	save_pos(filename);
	sprintf(filename,"POF/POF_MOEADVA_%s_OBJ%d_RUN%d.txt",strTestInstance, nobj, run);
	save_front(filename);

	population.clear();
	idealpoint.clear();
}

void CMOEAD::load_parameter() 
{
	char filename[1024];
	sprintf(filename,"ParameterSetting/\%s_%d.txt", strTestInstance, nobj);
	char temp[1024];
	std::ifstream readf(filename);
	readf.getline(temp, 1024);
	readf>>pops;
	readf>>max_gen;
	readf>>niche;
	readf>>limit;
	readf>>prob;
	readf>>rate;
	readf.close();
}

void CMOEAD::save_front(char saveFilename[1024])
{
    std::fstream fout;
	fout.open(saveFilename,std::ios::out);

	for(int n=0; n<pops; n++)	{
		for(int k=0;k<nobj;k++)
			fout<<population[n].indiv.y_obj[k]<<"  ";
		fout<<"\n";
	}
	fout.close();
}

void CMOEAD::save_pos(char saveFilename[1024])
{
    std::fstream fout;
	fout.open(saveFilename,std::ios::out);
	for(int n=0; n<pops; n++)	{
		for(int k=0;k<nvar;k++)
			fout<<population[n].indiv.x_var[k]<<"  ";
		fout<<"\n";
	}	
	fout.close();
}

#endif
