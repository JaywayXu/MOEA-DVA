The package is passed compiling under: MS Visual Studio 2005, 2008, 2010 in Windows.
  
1. Please read moea.cpp for details to setup and run the algorithm.
2. You can find the data in folds: POF (objective values) and POS (values of decision variables).
3. algorithm.h gives the detail of MOEA/DVA.
4. individual.h gives the structure of population and individual of population.
5. random.h gives a generator of random number.
6. TestInstance.tex gives the information of test problem: index, name, number of variables and number of objective functions.
7. cec09.h gives the implementation of MOP.
8. global.h defines the global variables.
9. common.h gives some utility functions.
10. In current MOEA/DVA, we just have the data for MOP with 2-4 diverse variables and the population size N=120 in fold: generate uniform points on supercube. If the population size N is not equal to 120, you should generate uniform values for diverse variables by yourself. If the number of diverse variables is greater than 4, we currently use random value to initialize the diverse variables.