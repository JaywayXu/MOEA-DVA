/*==========================================================================
// The code of MOEA/DVA is based the code of MOEA/D-DRA (Zhang et al., 2009).
// The code of MOEA/D-DRA can be download from: http://dces.essex.ac.uk/staff/qzhang/moeacompetition09.htm

// the details of MOEA/DVA in the following papers;
//  1) Xiaoliang Ma, Fang Liu, Yutao Qi. etal. A multiobjective evolutionary 
//     algorithm based on decision variable analyses. 
//     IEEE Transactions on Evolutionary Computation, 2014. (Under Review).
//  If you have any questions about the codes, please contact
//  Xiaoliang Ma       at   maxiaoliang@yeah.net
//
//  The initial version of MOEA/DVA at 10/Dec/2013
//  is updated at 11/August/2014
// ===========================================================================*/
#include "algorithm.h"

int main()
{
	int i,j;
	int fun_start_num = 11; // the start number of test function, you can find the explanation in TestInstance.txt
	int fun_end_num =29;    // the end number of test function
	int num_run = 2;        //the number of running MOEA/DVA independently

	char outFilename[1024];
	sprintf(outFilename, "LOG/LOG_MOEAD_IGD.dat", strTestInstance);
	std::fstream fout2;
	fout2.open(outFilename,std::ios::out);

	//skip the front MOP which is no need to be handled.
	int seq;
	std::ifstream readf("TestInstance.txt");
	for (i =1;i<fun_start_num;i++)
	{
		readf>>seq;
		readf>>strTestInstance;
		readf>>nvar;
		readf>>nobj;
	}
	//The MOPs needed to be handled.
	for(inst=fun_start_num; inst<=fun_end_num; inst++)
	{	// the parameter setting of test instance
		readf>>seq;
		readf>>strTestInstance;
		readf>>nvar;
		readf>>nobj;
		//parameter for WFG test problems
		position_parameters = 2 * (nobj -1);

		printf("\n -- Instance: %s, %d variables %d objectives \n\n", strTestInstance, nvar, nobj);

		clock_t start, temp, finish;
		double  duration, last = 0;
		start = clock();
		std::fstream fout;
		char logFilename[1024];
		sprintf(logFilename, "LOG/LOG_MOEAD_%s.dat", strTestInstance);
		fout.open(logFilename,std::ios::out);
		fout<<"Time: "<<endl;
		fout<<"Inst: "<<strTestInstance<<endl;

		CMOEAD MOEAD;
		MOEAD.load_parameter();

		strcpy(strFunctionType,"_MTCH2"); 
		ParameterSet();//get  the domain of x_var.
		num_max_evulation = 300000;

		for(int run=1; run<=num_run; run++)		{
			printf("\n -- %d-th run  -- \n", run);			
			MOEAD.exec_emo(run);

			temp = clock();
			duration = (double)(temp - start) / CLOCKS_PER_SEC;
			fout<<duration - last<<endl;
			last = duration;
		}
		finish = clock();
		duration = (double)(finish - start) / CLOCKS_PER_SEC;

		fout<<"Mean  CPU Time  "<<duration/num_run<<" seconds"<<endl;
		fout<<"Total CPU Time  "<<duration<<" seconds"<<endl;
		fout.close();
	}

	lowBound.clear();
	uppBound.clear();
	idealpoint.clear();
}
